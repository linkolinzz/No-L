from database.db_manager import connect_db

print("🔍 Перевіряємо підключення до бази даних...")

try:
    cn = connect_db()
    cur = cn.cursor(dictionary=True)

    cur.execute("SELECT DATABASE() AS db")
    db_name = cur.fetchone()["db"]
    print(f"✅ Підключено до бази: {db_name}")

    print("\n📋 Доступні таблиці:")
    cur.execute("SHOW TABLES")
    for row in cur.fetchall():
        print(" -", list(row.values())[0])

    print("\n📦 Кількість записів у ключових таблицях:")
    for table in ["final_quality", "warehouse_moves", "warehouse_logs"]:
        cur.execute(f"SELECT COUNT(*) AS c FROM {table}")
        print(f" - {table}: {cur.fetchone()['c']} записів")

    cur.close()
    cn.close()
    print("\n✅ Підключення та вибірки успішні!")

except Exception as e:
    print("❌ Помилка з'єднання або SQL:", e)
